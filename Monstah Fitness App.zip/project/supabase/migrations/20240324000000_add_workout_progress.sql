-- Create workout_progress table
create table public.workout_progress (
    id uuid default uuid_generate_v4() primary key,
    user_id uuid references auth.users not null,
    date date not null,
    workouts integer not null,
    calories integer not null,
    minutes integer not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS
alter table public.workout_progress enable row level security;

-- Create policies
create policy "Users can view their own progress"
    on public.workout_progress for select
    using (auth.uid() = user_id);

create policy "Users can insert their own progress"
    on public.workout_progress for insert
    with check (auth.uid() = user_id);

create policy "Users can update their own progress"
    on public.workout_progress for update
    using (auth.uid() = user_id);

create policy "Users can delete their own progress"
    on public.workout_progress for delete
    using (auth.uid() = user_id);

-- Create indexes
create index workout_progress_user_id_idx on public.workout_progress(user_id);
create index workout_progress_date_idx on public.workout_progress(date);