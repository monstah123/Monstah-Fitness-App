import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase credentials');
}

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  },
  db: {
    schema: 'public'
  }
});

// Helper function to check if a user is an admin
export const isAdmin = async (userId) => {
  const { data, error } = await supabase
    .rpc('is_admin')
    .single();

  if (error) {
    console.error('Error checking admin status:', error);
    return false;
  }

  return data;
};

export default supabase;