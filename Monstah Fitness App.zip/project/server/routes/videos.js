import express from 'express';
import multer from 'multer';
import { 
  PutObjectCommand, 
  GetObjectCommand
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { s3Client } from '../index.js';
import supabase from '../db/supabase.js';

const router = express.Router();
const upload = multer();

const BUCKET_NAME = process.env.AWS_BUCKET_NAME;

// Upload video
router.post('/upload', upload.single('video'), async (req, res) => {
  try {
    const file = req.file;
    const { category, title, description } = req.body;
    
    const key = `videos/${category}/${Date.now()}-${file.originalname}`;
    
    const command = new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
      Body: file.buffer,
      ContentType: file.mimetype,
    });

    await s3Client.send(command);

    // Save video metadata to database
    const { data: video, error } = await supabase
      .from('videos')
      .insert([{
        title,
        description,
        category,
        s3_key: key
      }])
      .select()
      .single();

    if (error) throw error;

    res.json(video);
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Failed to upload video' });
  }
});

// Get videos by category
router.get('/category/:category', async (req, res) => {
  try {
    const { category } = req.params;

    const { data: videos, error } = await supabase
      .from('videos')
      .select()
      .eq('category', category)
      .order('created_at', { ascending: false });

    if (error) throw error;

    const videosWithUrls = await Promise.all(
      videos.map(async (video) => {
        const command = new GetObjectCommand({
          Bucket: BUCKET_NAME,
          Key: video.s3_key
        });
        
        const url = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
        
        return {
          ...video,
          url
        };
      })
    );

    res.json(videosWithUrls);
  } catch (error) {
    console.error('List error:', error);
    res.status(500).json({ error: 'Failed to list videos' });
  }
});

export const videoRoutes = router;