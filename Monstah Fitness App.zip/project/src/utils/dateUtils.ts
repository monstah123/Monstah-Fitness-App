import { format } from 'date-fns';

// Get user's timezone
export const getUserTimezone = (): string => {
  return Intl.DateTimeFormat().resolvedOptions().timeZone;
};

// Convert UTC date to user's local timezone
export const utcToLocal = (date: Date | string): Date => {
  const utcDate = new Date(date);
  const userTimezone = getUserTimezone();
  return new Date(utcDate.toLocaleString('en-US', { timeZone: userTimezone }));
};

// Convert local date to UTC
export const localToUtc = (date: Date): Date => {
  return new Date(date.toISOString());
};

// Format date with timezone
export const formatDateWithTz = (date: Date | string, formatStr: string): string => {
  const localDate = utcToLocal(date);
  return format(localDate, formatStr);
};