import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true // Note: In production, API calls should be made through a backend
});

export async function generateMealPlan(instructions: string, calories: number, language: string) {
  if (!import.meta.env.VITE_OPENAI_API_KEY) {
    throw new Error('OpenAI API key is not configured');
  }

  try {
    const completion = await openai.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are an expert nutritionist and certified dietitian specializing in personalized meal planning. Provide detailed, practical, and scientifically-backed meal plans that are both healthy and delicious. Respond in ${language}.`
        },
        {
          role: "user",
          content: `Create a comprehensive daily meal plan following these specifications:
            - Diet type: ${instructions}
            - Daily calorie target: ${calories} calories
            
            Please structure the response exactly as follows:
            
            BREAKFAST (xxx calories):
            - Main dish (with portions)
            - Side items (with portions)
            - Beverage
            - Cooking instructions
            
            LUNCH (xxx calories):
            - Main dish (with portions)
            - Side items (with portions)
            - Beverage
            - Cooking instructions
            
            DINNER (xxx calories):
            - Main dish (with portions)
            - Side items (with portions)
            - Beverage
            - Cooking instructions
            
            SNACKS (xxx calories):
            - Morning snack (with timing)
            - Afternoon snack (with timing)
            
            MACRONUTRIENT BREAKDOWN:
            - Protein: xx% (xx grams)
            - Carbs: xx% (xx grams)
            - Fats: xx% (xx grams)
            
            MEAL PREP TIPS:
            1. (Specific prep tip)
            2. (Time-saving tip)
            3. (Storage tip)
            
            SHOPPING LIST:
            - Proteins:
            - Vegetables:
            - Fruits:
            - Pantry items:
            - Beverages:`
        }
      ],
      model: "gpt-4",
      temperature: 0.7,
      max_tokens: 2000,
    });

    return completion.choices[0].message.content;
  } catch (error: any) {
    console.error('Error generating meal plan:', error);
    if (error.response?.data?.error?.message) {
      throw new Error(error.response.data.error.message);
    }
    throw new Error('Failed to generate meal plan. Please check your API key and try again.');
  }
}