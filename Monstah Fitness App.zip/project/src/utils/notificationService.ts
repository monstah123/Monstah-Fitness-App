import { toast } from 'react-hot-toast';
import useSound from 'use-sound';

export const showNotification = (title: string) => {
  // Request permission for notifications
  if (!('Notification' in window)) {
    console.log('This browser does not support notifications');
    return;
  }

  if (Notification.permission !== 'granted') {
    Notification.requestPermission();
  }

  // Show browser notification
  if (Notification.permission === 'granted') {
    new Notification('MONSTAH Fitness Reminder', {
      body: title,
      icon: '/vite.svg'
    });
  }

  // Show toast notification
  toast(title, {
    icon: '🏋️‍♂️',
    duration: 5000,
    style: {
      borderRadius: '10px',
      background: '#333',
      color: '#fff',
    },
  });

  // Play notification sound
  try {
    const audio = new Audio('/notification.mp3');
    audio.volume = 0.5;
    audio.play().catch(error => {
      console.error('Error playing notification sound:', error);
    });
  } catch (error) {
    console.error('Error creating audio object:', error);
  }
};

export const checkReminders = (reminders: any[]) => {
  const checkInterval = setInterval(() => {
    const now = new Date();
    
    reminders.forEach(reminder => {
      const reminderTime = new Date(reminder.date);
      const [hours, minutes] = reminder.time.split(':');
      reminderTime.setHours(parseInt(hours, 10));
      reminderTime.setMinutes(parseInt(minutes, 10));
      reminderTime.setSeconds(0);

      const timeDiff = Math.abs(now.getTime() - reminderTime.getTime());
      if (timeDiff < 60000) { // Within 1 minute
        showNotification(reminder.title);
      }
    });
  }, 30000); // Check every 30 seconds

  // Cleanup interval on component unmount
  return () => clearInterval(checkInterval);
};