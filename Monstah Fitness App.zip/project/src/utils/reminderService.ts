import { supabase } from './supabase';
import { Reminder } from '../types/reminder';
import { localToUtc } from './dateUtils';

export const createReminder = async (reminderData: Omit<Reminder, 'id' | 'userId'>) => {
  const { data: session } = await supabase.auth.getSession();
  if (!session.session) {
    throw new Error('User not authenticated');
  }

  // Convert local date to UTC before saving
  const utcDate = localToUtc(new Date(reminderData.date));

  const { data, error } = await supabase
    .from('reminders')
    .insert([
      {
        ...reminderData,
        date: utcDate.toISOString(),
        user_id: session.session.user.id,
      },
    ])
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getReminders = async () => {
  const { data: session } = await supabase.auth.getSession();
  if (!session.session) {
    throw new Error('User not authenticated');
  }

  const { data, error } = await supabase
    .from('reminders')
    .select('*')
    .eq('user_id', session.session.user.id)
    .order('date', { ascending: true });

  if (error) throw error;
  return data;
};

export const deleteReminder = async (id: string) => {
  const { error } = await supabase
    .from('reminders')
    .delete()
    .eq('id', id);

  if (error) throw error;
};