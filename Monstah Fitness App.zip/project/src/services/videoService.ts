import { getVideoUrl } from '../utils/aws';

interface VideoCache {
  [key: string]: {
    url: string;
    expires: number;
  };
}

class VideoService {
  private static instance: VideoService;
  private cache: VideoCache = {};
  private readonly CACHE_DURATION = 55 * 60 * 1000; // 55 minutes

  private constructor() {}

  static getInstance(): VideoService {
    if (!VideoService.instance) {
      VideoService.instance = new VideoService();
    }
    return VideoService.instance;
  }

  async getVideoUrl(key: string): Promise<string> {
    if (!key) {
      throw new Error('Video key is required');
    }

    // Check cache first
    const cached = this.cache[key];
    if (cached && Date.now() < cached.expires) {
      return cached.url;
    }

    try {
      const url = await getVideoUrl(key);
      
      // Cache the URL
      this.cache[key] = {
        url,
        expires: Date.now() + this.CACHE_DURATION
      };

      return url;
    } catch (error) {
      console.error('Failed to get video URL:', error);
      throw error;
    }
  }

  clearCache() {
    this.cache = {};
  }
}

export const videoService = VideoService.getInstance();