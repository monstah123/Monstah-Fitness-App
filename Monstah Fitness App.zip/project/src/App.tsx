import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import WorkoutSection from './components/WorkoutSection';
import NutritionSection from './components/NutritionSection';
import AdminPanel from './components/admin/AdminPanel';
import LoginForm from './components/auth/LoginForm';
import MealPlanner from './components/MealPlanner';

function App() {
  const [activeSection, setActiveSection] = useState('workout');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const isAdmin = localStorage.getItem('adminToken') !== null;

  useEffect(() => {
    const token = localStorage.getItem('userToken');
    if (token) {
      setIsAuthenticated(true);
    }
  }, []);

  const handleLoginSuccess = (token: string) => {
    setIsAuthenticated(true);
    setActiveSection('workout');
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar 
        activeSection={activeSection} 
        setActiveSection={setActiveSection}
        isAdmin={isAdmin}
        isAuthenticated={isAuthenticated}
      />
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeSection === 'login' ? (
          <LoginForm onSuccess={handleLoginSuccess} />
        ) : activeSection === 'admin' && isAdmin ? (
          <AdminPanel />
        ) : activeSection === 'workout' ? (
          <WorkoutSection 
            isAuthenticated={isAuthenticated} 
            setActiveSection={setActiveSection}
          />
        ) : activeSection === 'mealplan' ? (
          <MealPlanner 
            selectedPlan="" 
            isAuthenticated={isAuthenticated} 
            setActiveSection={setActiveSection}
          />
        ) : (
          <NutritionSection 
            isAuthenticated={isAuthenticated} 
            setActiveSection={setActiveSection}
          />
        )}
      </main>
    </div>
  );
}

export default App;