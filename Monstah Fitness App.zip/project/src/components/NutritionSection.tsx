import React, { useState, useRef } from 'react';
import WeightTracker from './WeightTracker';
import MealPlanner from './MealPlanner';

const dietPlans = [
  {
    name: 'Vegan',
    image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=500&q=80',
    features: ['Plant-based meals', 'Protein alternatives', 'Nutritional guidance']
  },
  {
    name: 'Ketogenic',
    image: 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=500&q=80',
    features: ['High-fat meal plans', 'Low-carb recipes', 'Ketosis tracking']
  },
  {
    name: 'Paleo',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=500&q=80',
    features: ['Whole food focus', 'Grain-free options', 'Natural ingredients']
  },
  {
    name: 'Mediterranean',
    image: 'https://images.unsplash.com/photo-1556040220-4096d522378d?auto=format&fit=crop&w=500&q=80',
    features: ['Heart-healthy meals', 'Seafood options', 'Olive oil based']
  }
];

interface NutritionSectionProps {
  isAuthenticated: boolean;
  setActiveSection: (section: string) => void;
}

export default function NutritionSection({ isAuthenticated, setActiveSection }: NutritionSectionProps) {
  const [selectedPlan, setSelectedPlan] = useState('');
  const mealPlannerRef = useRef<HTMLDivElement>(null);

  const handlePlanSelect = (planName: string) => {
    setSelectedPlan(planName);
    setTimeout(() => {
      mealPlannerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-4">
          Fuel Your <span className="text-[#39FF14]">Transformation</span>
        </h2>
        <p className="text-gray-400">Select a nutrition plan that matches your goals</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {dietPlans.map((plan) => (
          <div key={plan.name} className="bg-gray-900 rounded-xl p-6 hover:border-[#39FF14] border-2 border-transparent transition-all">
            <div 
              className="relative h-48 mb-4 rounded-lg overflow-hidden cursor-pointer"
              onClick={() => handlePlanSelect(plan.name)}
            >
              <img
                src={plan.image}
                alt={plan.name}
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
            <h3 className="text-xl font-bold mb-4">{plan.name} Plan</h3>
            <ul className="space-y-3 mb-6">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-center">
                  <span className="w-2 h-2 bg-[#39FF14] rounded-full mr-2" />
                  <span className="text-gray-300">{feature}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={() => handlePlanSelect(plan.name)}
              className="w-full bg-[#39FF14] text-black py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors"
            >
              Choose Plan
            </button>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <WeightTracker isAuthenticated={isAuthenticated} setActiveSection={setActiveSection} />
        <div ref={mealPlannerRef}>
          <MealPlanner 
            selectedPlan={selectedPlan} 
            isAuthenticated={isAuthenticated} 
            setActiveSection={setActiveSection} 
          />
        </div>
      </div>
    </div>
  );
}