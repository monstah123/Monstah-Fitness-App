import React, { useState } from 'react';
import { LineChart as Chart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Scale, LogIn } from 'lucide-react';

interface WeightTrackerProps {
  isAuthenticated: boolean;
  setActiveSection?: (section: string) => void;
}

export default function WeightTracker({ isAuthenticated, setActiveSection }: WeightTrackerProps) {
  const [weight, setWeight] = useState('');
  const [weightData, setWeightData] = useState([
    { date: '1/1', weight: 180 },
    { date: '1/8', weight: 178 },
    { date: '1/15', weight: 176 },
    { date: '1/22', weight: 175 },
  ]);

  if (!isAuthenticated) {
    return (
      <div className="bg-gray-900 rounded-xl p-6">
        <div className="text-center">
          <h3 className="text-xl font-bold mb-4">Login Required</h3>
          <p className="text-gray-400 mb-4">Please login or register to track your weight</p>
          <button
            onClick={() => setActiveSection?.('login')}
            className="flex items-center gap-2 bg-[#39FF14] text-black px-6 py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors mx-auto"
          >
            <LogIn className="w-5 h-5" />
            Login / Register
          </button>
        </div>
      </div>
    );
  }

  const handleAddWeight = (e: React.FormEvent) => {
    e.preventDefault();
    const newWeight = parseFloat(weight);
    if (!isNaN(newWeight)) {
      const today = new Date();
      const date = `${today.getMonth() + 1}/${today.getDate()}`;
      setWeightData([...weightData, { date, weight: newWeight }]);
      setWeight('');
    }
  };

  return (
    <div className="bg-gray-900 rounded-xl p-6">
      <div className="flex items-center mb-6">
        <Scale className="w-6 h-6 text-[#39FF14] mr-2" />
        <h3 className="text-xl font-bold">Weight Tracker</h3>
      </div>

      <div className="h-64 mb-6">
        <ResponsiveContainer width="100%" height="100%">
          <Chart data={weightData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="date" stroke="#666" />
            <YAxis stroke="#666" domain={[0, 300]} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1a1a1a', border: 'none' }}
              labelStyle={{ color: '#39FF14' }}
            />
            <Line 
              type="monotone" 
              dataKey="weight" 
              stroke="#39FF14" 
              strokeWidth={2}
              dot={{ fill: '#39FF14' }}
            />
          </Chart>
        </ResponsiveContainer>
      </div>

      <form onSubmit={handleAddWeight} className="flex gap-4">
        <input
          type="number"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          placeholder="Enter weight"
          className="flex-1 bg-gray-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
          min="0"
          max="300"
          step="0.1"
        />
        <button
          type="submit"
          className="bg-[#39FF14] text-black px-6 py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors"
        >
          Add
        </button>
      </form>
    </div>
  );
}