import React from 'react';
import { Dumbbell, Utensils, Settings, LogIn, ChefHat, ShoppingBag } from 'lucide-react';

interface NavbarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
  isAdmin: boolean;
  isAuthenticated: boolean;
}

export default function Navbar({ activeSection, setActiveSection, isAdmin, isAuthenticated }: NavbarProps) {
  const handleShopClick = () => {
    window.open('https://monstahgymwear.com', '_blank');
  };

  return (
    <nav className="bg-gray-900 border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold">
              <span className="text-[#39FF14]">MONSTAH</span> FITNESS
            </h1>
          </div>
          <div className="flex space-x-4">
            <button
              onClick={() => setActiveSection('workout')}
              className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                activeSection === 'workout'
                  ? 'bg-[#39FF14] text-black'
                  : 'text-gray-300 hover:text-[#39FF14]'
              }`}
            >
              <Dumbbell className="w-5 h-5 mr-2" />
              Workouts
            </button>
            <button
              onClick={() => setActiveSection('mealplan')}
              className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                activeSection === 'mealplan'
                  ? 'bg-[#39FF14] text-black'
                  : 'text-gray-300 hover:text-[#39FF14]'
              }`}
            >
              <ChefHat className="w-5 h-5 mr-2" />
              Meal Plan
            </button>
            <button
              onClick={() => setActiveSection('nutrition')}
              className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                activeSection === 'nutrition'
                  ? 'bg-[#39FF14] text-black'
                  : 'text-gray-300 hover:text-[#39FF14]'
              }`}
            >
              <Utensils className="w-5 h-5 mr-2" />
              Nutrition
            </button>
            <button
              onClick={handleShopClick}
              className="flex items-center px-4 py-2 rounded-lg transition-colors text-gray-300 hover:text-[#39FF14] hover:scale-105 transform"
            >
              <ShoppingBag className="w-5 h-5 mr-2" />
              Shop
            </button>
            {isAdmin && (
              <button
                onClick={() => setActiveSection('admin')}
                className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                  activeSection === 'admin'
                    ? 'bg-[#39FF14] text-black'
                    : 'text-gray-300 hover:text-[#39FF14]'
                }`}
              >
                <Settings className="w-5 h-5 mr-2" />
                Admin
              </button>
            )}
            <button
              onClick={() => setActiveSection('login')}
              className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                activeSection === 'login'
                  ? 'bg-[#39FF14] text-black'
                  : 'text-gray-300 hover:text-[#39FF14]'
              }`}
            >
              <LogIn className="w-5 h-5 mr-2" />
              {isAuthenticated ? 'Account' : 'Login'}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}