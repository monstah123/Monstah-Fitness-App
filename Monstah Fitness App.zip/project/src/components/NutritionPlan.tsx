import React, { useState } from 'react';
import { Scale, Utensils, ChevronDown, LineChart } from 'lucide-react';
import WeightTracker from './WeightTracker';
import MealPlanner from './MealPlanner';

const dietPlans = [
  {
    name: 'Vegan',
    price: 29.99,
    features: ['Plant-based meals', 'Protein alternatives', 'Nutritional guidance']
  },
  {
    name: 'Ketogenic',
    price: 34.99,
    features: ['High-fat meal plans', 'Low-carb recipes', 'Ketosis tracking']
  },
  {
    name: 'Paleo',
    price: 32.99,
    features: ['Whole food focus', 'Grain-free options', 'Natural ingredients']
  },
  {
    name: 'Mediterranean',
    price: 29.99,
    features: ['Heart-healthy meals', 'Seafood options', 'Olive oil based']
  }
];

export default function NutritionPlan() {
  const [selectedPlan, setSelectedPlan] = useState('');
  const [showPlanner, setShowPlanner] = useState(false);

  return (
    <div className="min-h-screen bg-black text-white py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold mb-4">
            <span className="text-[#39FF14]">MONSTAH</span> NUTRITION
          </h1>
          <p className="text-gray-400">Fuel your transformation with custom meal plans</p>
        </div>

        {/* Subscription Plans */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {dietPlans.map((plan) => (
            <div key={plan.name} className="bg-gray-900 rounded-xl p-6 hover:border-[#39FF14] border-2 border-transparent transition-all">
              <h3 className="text-xl font-bold mb-4">{plan.name} Plan</h3>
              <p className="text-3xl font-bold text-[#39FF14] mb-6">
                ${plan.price}
                <span className="text-sm text-gray-400">/month</span>
              </p>
              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Utensils className="w-5 h-5 text-[#39FF14] mr-2" />
                    <span className="text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>
              <button
                onClick={() => {
                  setSelectedPlan(plan.name);
                  setShowPlanner(true);
                }}
                className="w-full bg-[#39FF14] text-black py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors"
              >
                Choose Plan
              </button>
            </div>
          ))}
        </div>

        {/* Tracking Section */}
        <div className="grid md:grid-cols-2 gap-8">
          <WeightTracker />
          {showPlanner && <MealPlanner selectedPlan={selectedPlan} />}
        </div>
      </div>
    </div>
  );
}