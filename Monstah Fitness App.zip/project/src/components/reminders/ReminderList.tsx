import React from 'react';
import { Bell, Trash2, Calendar, Clock } from 'lucide-react';
import { formatDateWithTz } from '../../utils/dateUtils';
import { Reminder } from '../../types/reminder';
import { deleteReminder } from '../../utils/reminderService';

interface ReminderListProps {
  reminders: Reminder[];
  onDelete: (id: string) => void;
}

export default function ReminderList({ reminders, onDelete }: ReminderListProps) {
  const handleDelete = async (id: string) => {
    try {
      await deleteReminder(id);
      onDelete(id);
    } catch (error) {
      console.error('Failed to delete reminder:', error);
    }
  };

  if (reminders.length === 0) {
    return (
      <div className="text-center text-gray-400 py-8">
        <Bell className="w-12 h-12 mx-auto mb-4 opacity-50" />
        <p>No reminders set</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {reminders.map((reminder) => (
        <div
          key={reminder.id}
          className="bg-gray-800 rounded-lg p-4 flex items-center justify-between"
        >
          <div>
            <h4 className="font-semibold mb-2">{reminder.title}</h4>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                {formatDateWithTz(reminder.date, 'MMM d, yyyy')}
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                {formatDateWithTz(new Date(`2000-01-01T${reminder.time}`), 'h:mm a')}
              </div>
            </div>
            {reminder.repeat !== 'none' && (
              <div className="mt-1 text-sm text-[#39FF14]">
                Repeats: {reminder.repeat}
                {reminder.repeat === 'custom' && reminder.days && (
                  <span className="ml-2">
                    ({reminder.days.join(', ')})
                  </span>
                )}
              </div>
            )}
          </div>
          <button
            onClick={() => handleDelete(reminder.id)}
            className="text-red-500 hover:text-red-400 transition-colors"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      ))}
    </div>
  );
}