import React, { useState } from 'react';
import { X, Bell, Calendar, Clock, Repeat } from 'lucide-react';
import { format } from 'date-fns';
import { DayPicker } from 'react-day-picker';
import { createReminder } from '../../utils/reminderService';

interface ReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function ReminderModal({ isOpen, onClose, onSuccess }: ReminderModalProps) {
  const [title, setTitle] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [time, setTime] = useState('09:00');
  const [repeatOption, setRepeatOption] = useState('none');
  const [selectedDays, setSelectedDays] = useState<string[]>([]);

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createReminder({
        title,
        date: selectedDate,
        time,
        repeat: repeatOption,
        days: selectedDays,
      });
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Failed to create reminder:', error);
    }
  };

  const toggleDay = (day: string) => {
    setSelectedDays(prev =>
      prev.includes(day)
        ? prev.filter(d => d !== day)
        : [...prev, day]
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-xl p-6 w-full max-w-md relative max-h-[80vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-4 flex items-center">
          <Bell className="w-6 h-6 text-[#39FF14] mr-2" />
          Set Workout Reminder
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-gray-400 mb-1">Reminder Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Chest Day Workout"
              className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-400 mb-1 flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                Time
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                required
              />
            </div>
            <div>
              <label className="block text-gray-400 mb-1 flex items-center">
                <Repeat className="w-4 h-4 mr-1" />
                Repeat
              </label>
              <select
                value={repeatOption}
                onChange={(e) => setRepeatOption(e.target.value)}
                className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
              >
                <option value="none">Don't repeat</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="custom">Custom</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-gray-400 mb-1 flex items-center">
              <Calendar className="w-4 h-4 mr-1" />
              Select Date
            </label>
            <div className="bg-gray-800 rounded-lg p-2">
              <DayPicker
                mode="single"
                selected={selectedDate}
                onSelect={(date) => date && setSelectedDate(date)}
                className="!bg-gray-800 text-white"
                classNames={{
                  day_selected: "bg-[#39FF14] text-black rounded-lg",
                  day: "text-white hover:bg-gray-700 rounded-lg",
                  day_today: "text-[#39FF14] font-bold",
                  head_cell: "text-[#39FF14]",
                  caption: "text-white",
                  nav_button_previous: "text-[#39FF14] hover:text-[#32E512]",
                  nav_button_next: "text-[#39FF14] hover:text-[#32E512]",
                }}
              />
            </div>
          </div>

          {repeatOption === 'custom' && (
            <div>
              <label className="block text-gray-400 mb-1">Select Days</label>
              <div className="grid grid-cols-2 gap-2">
                {daysOfWeek.map((day) => (
                  <button
                    key={day}
                    type="button"
                    onClick={() => toggleDay(day)}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      selectedDays.includes(day)
                        ? 'bg-[#39FF14] text-black'
                        : 'bg-gray-800 text-white hover:bg-gray-700'
                    }`}
                  >
                    {day}
                  </button>
                ))}
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-[#39FF14] text-black py-3 rounded-lg font-bold hover:bg-[#32E512] transition-colors mt-4"
          >
            Set Reminder
          </button>
        </form>
      </div>
    </div>
  );
}