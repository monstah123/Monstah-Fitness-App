import React, { useState } from 'react';
import { Play, Loader2 } from 'lucide-react';
import { videoService } from '../services/videoService';

const POSING_VIDEO_KEY = 'Best Bodybuilding Training And Posing videos.mp4';

interface PosingVideoProps {
  onPlay: () => void;
  isSelected: boolean;
}

export default function PosingVideo({ onPlay, isSelected }: PosingVideoProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleClick = async () => {
    setLoading(true);
    setError(null);
    try {
      await onPlay();
    } catch (err) {
      setError('Failed to load video');
      console.error('Error playing video:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative">
      <button
        onClick={handleClick}
        disabled={loading}
        className={`w-full text-left px-4 py-2 rounded transition-colors flex items-center justify-between ${
          isSelected
            ? 'bg-[#39FF14] text-black'
            : 'bg-gray-800 hover:bg-gray-700'
        } ${loading ? 'opacity-75 cursor-wait' : ''}`}
      >
        <span>Posing Practice</span>
        {loading ? (
          <Loader2 className="w-4 h-4 animate-spin text-[#39FF14]" />
        ) : (
          <Play className={`w-4 h-4 ${isSelected ? 'text-black' : 'text-[#39FF14]'}`} />
        )}
      </button>
      {error && (
        <div className="absolute -bottom-8 left-0 right-0 text-red-500 text-sm bg-red-500/10 p-1 rounded">
          {error}
        </div>
      )}
    </div>
  );
}

export const getPosingVideoUrl = async (): Promise<string> => {
  try {
    const url = await videoService.getVideoUrl(POSING_VIDEO_KEY);
    if (!url) {
      throw new Error('Failed to get video URL');
    }
    return url;
  } catch (error) {
    console.error('Error getting posing video URL:', error);
    throw error;
  }
};