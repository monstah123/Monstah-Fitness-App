import React, { useState } from 'react';
import { Lock, Mail, User } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface LoginFormProps {
  onSuccess: (token: string) => void;
}

const PASSWORD_REQUIREMENTS = {
  minLength: 8,
  hasUpperCase: /[A-Z]/,
  hasLowerCase: /[a-z]/,
  hasNumber: /[0-9]/,
  hasSpecialChar: /[!@#$%^&*(),.?":{}|<>]/
};

export default function LoginForm({ onSuccess }: LoginFormProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const validatePassword = (password: string): string | null => {
    if (password.length < PASSWORD_REQUIREMENTS.minLength) {
      return `Password must be at least ${PASSWORD_REQUIREMENTS.minLength} characters long`;
    }
    if (!PASSWORD_REQUIREMENTS.hasUpperCase.test(password)) {
      return 'Password must contain at least one uppercase letter';
    }
    if (!PASSWORD_REQUIREMENTS.hasLowerCase.test(password)) {
      return 'Password must contain at least one lowercase letter';
    }
    if (!PASSWORD_REQUIREMENTS.hasNumber.test(password)) {
      return 'Password must contain at least one number';
    }
    if (!PASSWORD_REQUIREMENTS.hasSpecialChar.test(password)) {
      return 'Password must contain at least one special character';
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (!isLogin) {
        const passwordError = validatePassword(formData.password);
        if (passwordError) {
          setError(passwordError);
          setLoading(false);
          return;
        }
      }

      if (isLogin) {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: formData.email,
          password: formData.password,
        });

        if (error) throw error;
        if (data.session) {
          localStorage.setItem('userToken', data.session.access_token);
          onSuccess(data.session.access_token);
        }
      } else {
        const { data, error } = await supabase.auth.signUp({
          email: formData.email,
          password: formData.password,
          options: {
            data: {
              name: formData.name,
            },
          }
        });

        if (error) throw error;

        // Auto sign-in after registration
        const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
          email: formData.email,
          password: formData.password,
        });

        if (signInError) throw signInError;
        if (signInData.session) {
          localStorage.setItem('userToken', signInData.session.access_token);
          onSuccess(signInData.session.access_token);
        }
      }
    } catch (err: any) {
      console.error('Auth error:', err);
      if (err.message) {
        setError(err.message);
      } else if (err.error_description) {
        setError(err.error_description);
      } else {
        setError('Authentication failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="bg-gray-900 p-8 rounded-xl shadow-2xl border border-[#39FF14]/20">
        <h2 className="text-3xl font-bold mb-2 text-center">
          <span className="text-[#39FF14] text-shadow-glow">
            {isLogin ? 'Welcome Back' : 'Join MONSTAH'}
          </span>
        </h2>
        <p className="text-gray-400 text-center mb-8">
          {isLogin ? 'Login to access premium features' : 'Create your account'}
        </p>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-gray-400 mb-1">Name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-gray-800 rounded-lg pl-10 pr-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                  placeholder="Enter your name"
                  required
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-gray-400 mb-1">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full bg-gray-800 rounded-lg pl-10 pr-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                placeholder="Enter your email"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-400 mb-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full bg-gray-800 rounded-lg pl-10 pr-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                placeholder="Enter your password"
                required
                minLength={PASSWORD_REQUIREMENTS.minLength}
              />
            </div>
            {!isLogin && (
              <p className="text-gray-400 text-sm mt-2">
                Password must contain at least {PASSWORD_REQUIREMENTS.minLength} characters, including uppercase, lowercase, number, and special character.
              </p>
            )}
          </div>

          {error && (
            <div className="bg-red-500/10 text-red-500 px-4 py-2 rounded-lg">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#39FF14] text-black py-3 rounded-lg font-bold hover:bg-[#32E512] transition-colors disabled:opacity-50"
          >
            {loading ? 'Processing...' : isLogin ? 'Login' : 'Sign Up'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              setError('');
              setFormData({ email: '', password: '', name: '' });
            }}
            className="text-[#39FF14] hover:text-[#32E512] font-medium"
          >
            {isLogin ? "Don't have an account? Sign up" : 'Already have an account? Login'}
          </button>
        </div>
      </div>
    </div>
  );
}