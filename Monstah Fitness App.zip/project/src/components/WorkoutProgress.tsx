import React, { useState, useEffect } from 'react';
import { CalendarIcon, Clock, Flame, Trash2, LogIn } from 'lucide-react';
import { DayPicker } from 'react-day-picker';
import { format } from 'date-fns';
import 'react-day-picker/dist/style.css';

interface ProgressEntry {
  id: string;
  date: string;
  workouts: number;
  calories: number;
  minutes: number;
}

interface WorkoutProgressProps {
  isAuthenticated: boolean;
  setActiveSection?: (section: string) => void;
}

export default function WorkoutProgress({ isAuthenticated, setActiveSection }: WorkoutProgressProps) {
  const [workouts, setWorkouts] = useState(0);
  const [calories, setCalories] = useState(0);
  const [minutes, setMinutes] = useState(0);
  const [history, setHistory] = useState<ProgressEntry[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  useEffect(() => {
    if (isAuthenticated) {
      const savedHistory = localStorage.getItem('workoutHistory');
      if (savedHistory) {
        setHistory(JSON.parse(savedHistory));
      }
    }
  }, [isAuthenticated]);

  const handleSaveProgress = () => {
    if (!isAuthenticated) return;

    const formattedDate = format(selectedDate, 'yyyy-MM-dd');
    const newEntry: ProgressEntry = {
      id: crypto.randomUUID(),
      date: formattedDate,
      workouts,
      calories,
      minutes
    };

    const updatedHistory = [...history, newEntry];
    setHistory(updatedHistory);
    localStorage.setItem('workoutHistory', JSON.stringify(updatedHistory));

    // Reset form
    setWorkouts(0);
    setCalories(0);
    setMinutes(0);
  };

  const handleClearHistory = () => {
    if (!window.confirm('Are you sure you want to clear all history? This cannot be undone.')) {
      return;
    }

    setHistory([]);
    localStorage.removeItem('workoutHistory');
  };

  if (!isAuthenticated) {
    return (
      <div className="bg-gray-900 rounded-xl p-6">
        <div className="text-center">
          <h3 className="text-xl font-bold mb-4">Login Required</h3>
          <p className="text-gray-400 mb-4">Please login or register to track your progress</p>
          <button
            onClick={() => setActiveSection?.('login')}
            className="flex items-center gap-2 bg-[#39FF14] text-black px-6 py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors mx-auto"
          >
            <LogIn className="w-5 h-5" />
            Login / Register
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <CalendarIcon className="w-6 h-6 text-[#39FF14] mr-2" />
          <h3 className="text-xl font-bold">Today's Progress</h3>
        </div>
        {history.length > 0 && (
          <button
            onClick={handleClearHistory}
            className="flex items-center gap-2 text-red-500 hover:text-red-400 transition-colors"
          >
            <Trash2 className="w-5 h-5" />
            Clear History
          </button>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-gray-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-gray-400">Workouts</p>
            <CalendarIcon className="w-5 h-5 text-[#39FF14]" />
          </div>
          <input
            type="number"
            value={workouts}
            onChange={(e) => setWorkouts(Math.max(0, parseInt(e.target.value) || 0))}
            className="w-full bg-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
            min="0"
            max="10"
          />
        </div>
        <div className="bg-gray-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-gray-400">Calories Burned</p>
            <Flame className="w-5 h-5 text-[#39FF14]" />
          </div>
          <input
            type="number"
            value={calories}
            onChange={(e) => setCalories(Math.max(0, parseInt(e.target.value) || 0))}
            className="w-full bg-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
            min="0"
            step="10"
          />
        </div>
        <div className="bg-gray-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-gray-400">Time (minutes)</p>
            <Clock className="w-5 h-5 text-[#39FF14]" />
          </div>
          <input
            type="number"
            value={minutes}
            onChange={(e) => setMinutes(Math.max(0, parseInt(e.target.value) || 0))}
            className="w-full bg-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
            min="0"
            step="5"
          />
        </div>
      </div>

      <div className="mb-6">
        <div className="bg-gray-800 rounded-lg p-4">
          <DayPicker
            mode="single"
            selected={selectedDate}
            onSelect={(date) => date && setSelectedDate(date)}
            className="!bg-gray-800 text-white"
            classNames={{
              day_selected: "bg-[#39FF14] text-black rounded-lg",
              day: "text-white hover:bg-gray-700 rounded-lg",
              day_today: "text-[#39FF14] font-bold",
              head_cell: "text-[#39FF14]",
              caption: "text-white",
              nav_button_previous: "text-[#39FF14] hover:text-[#32E512]",
              nav_button_next: "text-[#39FF14] hover:text-[#32E512]",
            }}
          />
        </div>
      </div>

      <button
        onClick={handleSaveProgress}
        className="w-full bg-[#39FF14] text-black py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors"
      >
        Save Progress
      </button>

      {history.length > 0 && (
        <div className="mt-6">
          <h4 className="text-lg font-semibold mb-3">Progress History</h4>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {history.slice().reverse().map((entry) => (
              <div key={entry.id} className="bg-gray-800 rounded-lg p-3 flex justify-between items-center">
                <span className="text-gray-400">{entry.date}</span>
                <div className="flex gap-4">
                  <span className="text-[#39FF14]">{entry.workouts} workouts</span>
                  <span className="text-[#39FF14]">{entry.calories} cal</span>
                  <span className="text-[#39FF14]">{entry.minutes} min</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}