import React, { useState } from 'react';
import { Utensils, Search, Loader2, AlertCircle, Copy, Check, Globe2, LogIn } from 'lucide-react';
import { generateMealPlan } from '../utils/openai';

interface MealPlannerProps {
  selectedPlan: string;
  isAuthenticated: boolean;
  setActiveSection?: (section: string) => void;
}

const dietPlans = [
  'Carnivore diet',
  'Vegan diet',
  'Paleo diet',
  'Ketogenic diet',
  'Mediterranean diet',
  'Vegetarian diet',
  'South beach diet',
  'Whole30 diet',
  'Low carb diet',
  'Dash diet',
  'Flexitarian diet'
];

const languages = [
  { code: 'English', name: 'English' },
  { code: 'Spanish', name: 'Español' },
  { code: 'French', name: 'Français' },
  { code: 'Dutch', name: 'Nederlands' },
  { code: 'German', name: 'Deutsch' }
];

export default function MealPlanner({ selectedPlan, isAuthenticated, setActiveSection }: MealPlannerProps) {
  const [calories, setCalories] = useState('2000');
  const [customInstructions, setCustomInstructions] = useState('');
  const [selectedDiet, setSelectedDiet] = useState(dietPlans[0]);
  const [selectedLanguage, setSelectedLanguage] = useState(languages[0].code);
  const [mealPlan, setMealPlan] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isAuthenticated) {
    return (
      <div className="bg-gray-900 rounded-xl p-6">
        <div className="text-center">
          <h3 className="text-xl font-bold mb-4">Login Required</h3>
          <p className="text-gray-400 mb-4">Please login or register to access the meal planner</p>
          <button
            onClick={() => setActiveSection?.('login')}
            className="flex items-center gap-2 bg-[#39FF14] text-black px-6 py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors mx-auto"
          >
            <LogIn className="w-5 h-5" />
            Login / Register
          </button>
        </div>
      </div>
    );
  }

  const handleGenerateMealPlan = async () => {
    if (!import.meta.env.VITE_OPENAI_API_KEY) {
      setError('OpenAI API key is not configured. Please add it to your .env file.');
      return;
    }

    setLoading(true);
    setError('');
    try {
      const instructions = `${selectedDiet}${customInstructions ? `. Additional requirements: ${customInstructions}` : ''}`;
      const generatedPlan = await generateMealPlan(instructions, parseInt(calories), selectedLanguage);
      setMealPlan(generatedPlan || '');
    } catch (err: any) {
      setError(err.message || 'Failed to generate meal plan. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(mealPlan);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  return (
    <div className="bg-gray-900 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Utensils className="w-6 h-6 text-[#39FF14] mr-2" />
          <h3 className="text-xl font-bold">Custom Meal Plan Generator</h3>
        </div>
        {mealPlan && (
          <button
            onClick={handleCopy}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-[#39FF14]" />
                <span className="text-[#39FF14]">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Plan</span>
              </>
            )}
          </button>
        )}
      </div>

      <div className="space-y-6">
        <div className="space-y-4">
          <div>
            <label className="block text-gray-400 mb-2">Select Diet Type</label>
            <select
              value={selectedDiet}
              onChange={(e) => setSelectedDiet(e.target.value)}
              className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
            >
              {dietPlans.map((diet) => (
                <option key={diet} value={diet}>
                  {diet}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-gray-400 mb-2">
              <div className="flex items-center gap-2">
                <Globe2 className="w-5 h-5" />
                Select Language
              </div>
            </label>
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
            >
              {languages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-gray-400 mb-2">Daily Calorie Target</label>
            <input
              type="number"
              value={calories}
              onChange={(e) => setCalories(e.target.value)}
              placeholder="Enter daily calorie target"
              className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
              min="1200"
              max="5000"
            />
          </div>

          <div>
            <label className="block text-gray-400 mb-2">Additional Instructions</label>
            <div className="relative">
              <Search className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
              <textarea
                value={customInstructions}
                onChange={(e) => setCustomInstructions(e.target.value)}
                placeholder="E.g., No nuts, high protein, gluten-free, specific allergies, preferred ingredients..."
                className="w-full bg-gray-800 rounded-lg pl-10 pr-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14] min-h-[100px]"
              />
            </div>
          </div>

          {error && (
            <div className="bg-red-500/10 text-red-500 px-4 py-2 rounded-lg flex items-center">
              <AlertCircle className="w-5 h-5 mr-2" />
              {error}
            </div>
          )}

          <button
            onClick={handleGenerateMealPlan}
            disabled={loading}
            className="w-full bg-[#39FF14] text-black py-3 rounded-lg font-bold hover:bg-[#32E512] transition-colors disabled:opacity-50 flex items-center justify-center"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Generating Plan...
              </>
            ) : (
              'Generate Meal Plan'
            )}
          </button>

          {mealPlan && (
            <div className="bg-gray-800 rounded-lg p-6 mt-4">
              <h4 className="text-[#39FF14] text-lg font-bold mb-4">Your Custom Meal Plan</h4>
              <div className="text-gray-300 whitespace-pre-line prose prose-invert max-w-none">
                {mealPlan}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}