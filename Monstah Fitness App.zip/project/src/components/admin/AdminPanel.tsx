import React, { useState, useEffect } from 'react';
import { Upload, Trash2, Play } from 'lucide-react';

interface Video {
  key: string;
  url: string;
  lastModified: string;
}

const categories = [
  'chest', 'back', 'shoulders', 'arms', 
  'legs', 'calves', 'core'
];

export default function AdminPanel() {
  const [videos, setVideos] = useState<{ [key: string]: Video[] }>({});
  const [selectedCategory, setSelectedCategory] = useState(categories[0]);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchVideos(selectedCategory);
  }, [selectedCategory]);

  const fetchVideos = async (category: string) => {
    try {
      const response = await fetch(`/api/videos/category/${category}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to fetch videos');
      const data = await response.json();
      setVideos(prev => ({ ...prev, [category]: data }));
    } catch (err) {
      setError('Failed to load videos');
    }
  };

  const handleUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setError('');

    const formData = new FormData();
    formData.append('video', file);
    formData.append('category', selectedCategory);
    formData.append('title', file.name);

    try {
      const response = await fetch('/api/videos/upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        },
        body: formData
      });

      if (!response.ok) throw new Error('Upload failed');
      
      await fetchVideos(selectedCategory);
    } catch (err) {
      setError('Failed to upload video');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="bg-gray-900 rounded-xl p-6">
        <h2 className="text-2xl font-bold mb-6">Video Management</h2>

        <div className="flex gap-4 mb-6">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </option>
            ))}
          </select>

          <label className="flex items-center gap-2 bg-[#39FF14] text-black px-6 py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors cursor-pointer">
            <Upload className="w-5 h-5" />
            Upload Video
            <input
              type="file"
              accept="video/*"
              onChange={handleUpload}
              className="hidden"
            />
          </label>
        </div>

        {error && (
          <div className="bg-red-500/10 text-red-500 px-4 py-2 rounded-lg mb-4">
            {error}
          </div>
        )}

        {isUploading && (
          <div className="bg-[#39FF14]/10 text-[#39FF14] px-4 py-2 rounded-lg mb-4">
            Uploading video...
          </div>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {videos[selectedCategory]?.map((video) => (
            <div key={video.key} className="bg-gray-800 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold truncate">
                  {video.key.split('/').pop()}
                </h3>
                <button className="text-red-500 hover:text-red-400">
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
              <a
                href={video.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-[#39FF14] hover:text-[#32E512]"
              >
                <Play className="w-4 h-4" />
                Preview
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}