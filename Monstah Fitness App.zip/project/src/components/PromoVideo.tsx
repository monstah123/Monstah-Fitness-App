import React, { useState, useEffect } from 'react';
import { videoService } from '../services/videoService';
import VideoPlayer from './VideoPlayer';

const PROMO_VIDEO_KEY = 'This Preworkout Anthem Will Have You Lifting Like a Superhero! 💪🔥.mp4';

export default function PromoVideo() {
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadVideo = async () => {
      try {
        const url = await videoService.getVideoUrl(PROMO_VIDEO_KEY);
        setVideoUrl(url);
      } catch (err) {
        console.error('Failed to load promo video:', err);
        setError('Unable to load promo video');
      }
    };

    loadVideo();
  }, []);

  return (
    <div className="bg-gray-900 rounded-xl p-6">
      <h3 className="text-xl font-bold mb-4">
        <span className="text-[#39FF14]">Preworkout</span> Anthem
      </h3>
      <div className="aspect-video rounded-lg overflow-hidden bg-black">
        {videoUrl && (
          <VideoPlayer
            src={videoUrl}
            poster="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200&q=80"
            onError={(err) => setError(err.message)}
            className="w-full h-full"
          />
        )}
      </div>
    </div>
  );
}