import React, { useState, useEffect } from 'react';
import { Dumbbell, Flame, Trophy } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';
import VideoModal from './VideoModal';
import WorkoutProgress from './WorkoutProgress';
import WorkoutReminders from './WorkoutReminders';
import MealPlanner from './MealPlanner';
import PromoVideo from './PromoVideo';
import TabataVideo, { getTabataVideoUrl } from './TabataVideo';
import ShoulderVideo, { getShoulderVideoUrl } from './ShoulderVideo';
import PosingVideo, { getPosingVideoUrl } from './PosingVideo';

interface WorkoutSectionProps {
  isAuthenticated: boolean;
  setActiveSection: (section: string) => void;
}

interface Video {
  id: string;
  title: string;
  description?: string;
  category: string;
  s3_key: string;
  url?: string;
}

const workoutCategories = [
  {
    title: 'Strength Training',
    description: 'Build muscle and increase strength',
    icon: Dumbbell,
    workouts: [
      { name: 'Chest & Triceps', category: 'chest' },
      { name: 'Back & Biceps', category: 'back' },
      { name: 'Legs & Calves', category: 'legs' },
      { name: 'Shoulders & Traps', category: 'shoulders' }
    ]
  },
  {
    title: 'HIIT',
    description: 'High-intensity interval training',
    icon: Flame,
    workouts: [
      { name: 'Tabata', category: 'hiit' },
      { name: 'Circuit Training', category: 'hiit' },
      { name: 'CrossFit Style', category: 'hiit' }
    ]
  },
  {
    title: 'Competition Prep',
    description: 'Get ready for the stage',
    icon: Trophy,
    workouts: [
      { name: 'Posing Practice', category: 'competition' },
      { name: 'Peak Week Training', category: 'competition' },
      { name: 'Contest Prep', category: 'competition' }
    ]
  }
];

export default function WorkoutSection({ isAuthenticated, setActiveSection }: WorkoutSectionProps) {
  const [selectedWorkout, setSelectedWorkout] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const mealPlannerRef = React.useRef<HTMLDivElement>(null);

  const handleWorkoutClick = async (workout: { name: string; category: string }) => {
    setSelectedWorkout(workout.name);
    setSelectedCategory(workout.category);
    
    if (workout.name === 'Tabata') {
      try {
        setLoading(true);
        const url = await getTabataVideoUrl();
        setSelectedVideo({
          id: 'tabata-training',
          title: 'Tabata Training',
          description: 'High-intensity interval training for maximum results',
          category: 'hiit',
          s3_key: 'latest tabata dance.mp4',
          url
        });
      } catch (err) {
        console.error('Error getting video URL:', err);
        setError('Failed to load video');
      } finally {
        setLoading(false);
      }
    } else if (workout.name === 'Shoulders & Traps') {
      try {
        setLoading(true);
        const url = await getShoulderVideoUrl();
        setSelectedVideo({
          id: 'shoulder-mass',
          title: 'Top 5 Shoulder Mass Exercises',
          description: 'Build massive shoulders with these key exercises',
          category: 'shoulders',
          s3_key: 'Top 5 SHOULDER MASS Exercises!.mp4',
          url
        });
      } catch (err) {
        console.error('Error getting video URL:', err);
        setError('Failed to load video');
      } finally {
        setLoading(false);
      }
    } else if (workout.name === 'Posing Practice') {
      try {
        setLoading(true);
        const url = await getPosingVideoUrl();
        setSelectedVideo({
          id: 'posing-practice',
          title: 'Bodybuilding Posing Practice',
          description: 'Master your posing routine for competition',
          category: 'competition',
          s3_key: 'Best Bodybuilding Training And Posing videos.mp4',
          url
        });
      } catch (err) {
        console.error('Error getting video URL:', err);
        setError('Failed to load video');
      } finally {
        setLoading(false);
      }
    }

    if (['Vegan', 'Ketogenic', 'Paleo', 'Mediterranean'].includes(workout.name)) {
      setTimeout(() => {
        mealPlannerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 100);
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-4">
          Transform Your <span className="text-[#39FF14]">Body</span>
        </h2>
        <p className="text-gray-400">Choose your workout category and start training</p>
      </div>

      <PromoVideo />

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {workoutCategories.map((category) => (
          <div key={category.title} className="bg-gray-900 rounded-xl p-6 hover:border-[#39FF14] border-2 border-transparent transition-all">
            <category.icon className="w-8 h-8 text-[#39FF14] mb-4" />
            <h3 className="text-xl font-bold mb-2">{category.title}</h3>
            <p className="text-gray-400 mb-4">{category.description}</p>
            <div className="space-y-2">
              {category.workouts.map((workout) => (
                workout.name === 'Tabata' ? (
                  <TabataVideo
                    key={workout.name}
                    onPlay={() => handleWorkoutClick(workout)}
                    isSelected={selectedWorkout === workout.name}
                  />
                ) : workout.name === 'Shoulders & Traps' ? (
                  <ShoulderVideo
                    key={workout.name}
                    onPlay={() => handleWorkoutClick(workout)}
                    isSelected={selectedWorkout === workout.name}
                  />
                ) : workout.name === 'Posing Practice' ? (
                  <PosingVideo
                    key={workout.name}
                    onPlay={() => handleWorkoutClick(workout)}
                    isSelected={selectedWorkout === workout.name}
                  />
                ) : (
                  <button
                    key={workout.name}
                    onClick={() => handleWorkoutClick(workout)}
                    className={`w-full text-left px-4 py-2 rounded transition-colors ${
                      selectedWorkout === workout.name
                        ? 'bg-[#39FF14] text-black'
                        : 'bg-gray-800 hover:bg-gray-700'
                    }`}
                  >
                    {workout.name}
                  </button>
                )
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <WorkoutProgress isAuthenticated={isAuthenticated} setActiveSection={setActiveSection} />
        <WorkoutReminders isAuthenticated={isAuthenticated} setActiveSection={setActiveSection} />
        <div ref={mealPlannerRef}>
          <MealPlanner 
            selectedPlan={selectedCategory || ''} 
            isAuthenticated={isAuthenticated} 
            setActiveSection={setActiveSection} 
          />
        </div>
      </div>

      {selectedVideo && selectedVideo.url && (
        <VideoModal
          videoUrl={selectedVideo.url}
          title={selectedVideo.title}
          onClose={() => setSelectedVideo(null)}
        />
      )}

      {loading && (
        <div className="bg-[#39FF14]/10 text-[#39FF14] px-4 py-2 rounded-lg">
          Loading video...
        </div>
      )}

      {error && (
        <div className="bg-red-500/10 text-red-500 px-4 py-2 rounded-lg">
          {error}
        </div>
      )}
    </div>
  );
}