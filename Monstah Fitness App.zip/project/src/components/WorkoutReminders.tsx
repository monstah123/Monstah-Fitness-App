import React, { useState, useEffect } from 'react';
import { Bell, Plus } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import ReminderModal from './reminders/ReminderModal';
import ReminderList from './reminders/ReminderList';
import { getReminders } from '../utils/reminderService';
import { checkReminders } from '../utils/notificationService';
import { Reminder } from '../types/reminder';

interface WorkoutRemindersProps {
  isAuthenticated: boolean;
  setActiveSection: (section: string) => void;
}

export default function WorkoutReminders({ isAuthenticated, setActiveSection }: WorkoutRemindersProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [reminders, setReminders] = useState<Reminder[]>([]);

  useEffect(() => {
    if (isAuthenticated) {
      loadReminders();
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (reminders.length > 0) {
      checkReminders(reminders);
    }
  }, [reminders]);

  const loadReminders = async () => {
    try {
      const data = await getReminders();
      setReminders(data);
    } catch (error) {
      console.error('Failed to load reminders:', error);
    }
  };

  const handleReminderSuccess = () => {
    loadReminders();
  };

  const handleDelete = (id: string) => {
    setReminders(prev => prev.filter(reminder => reminder.id !== id));
  };

  if (!isAuthenticated) {
    return (
      <div className="bg-gray-900 rounded-xl p-6">
        <div className="text-center">
          <h3 className="text-xl font-bold mb-4">Login Required</h3>
          <p className="text-gray-400 mb-4">Please login to set workout reminders</p>
          <button
            onClick={() => setActiveSection('login')}
            className="bg-[#39FF14] text-black px-6 py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors"
          >
            Login / Register
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 rounded-xl p-6">
      <Toaster position="top-right" />
      
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Bell className="w-6 h-6 text-[#39FF14] mr-2" />
          <h3 className="text-xl font-bold">Workout Reminders</h3>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-[#39FF14] text-black px-4 py-2 rounded-lg font-bold hover:bg-[#32E512] transition-colors"
        >
          <Plus className="w-5 h-5" />
          Add Reminder
        </button>
      </div>

      <ReminderList reminders={reminders} onDelete={handleDelete} />

      <ReminderModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSuccess={handleReminderSuccess}
      />
    </div>
  );
}