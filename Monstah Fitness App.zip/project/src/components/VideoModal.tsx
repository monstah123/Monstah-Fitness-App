import React, { useEffect, useRef } from 'react';
import { X, Loader2 } from 'lucide-react';

interface VideoModalProps {
  videoUrl: string;
  title: string;
  onClose: () => void;
}

export default function VideoModal({ videoUrl, title, onClose }: VideoModalProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleCanPlay = () => setLoading(false);
    const handleError = () => {
      setLoading(false);
      setError('Failed to load video. Please try again.');
    };

    video.addEventListener('canplay', handleCanPlay);
    video.addEventListener('error', handleError);

    video.load();

    return () => {
      video.removeEventListener('canplay', handleCanPlay);
      video.removeEventListener('error', handleError);
    };
  }, [videoUrl]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80">
      <div className="relative w-full max-w-4xl mx-4">
        <button
          onClick={onClose}
          className="absolute -top-12 right-0 text-white hover:text-[#39FF14] transition-colors"
        >
          <X className="w-8 h-8" />
        </button>
        
        <div className="bg-gray-900 rounded-xl overflow-hidden">
          <h3 className="text-xl font-bold p-4">{title}</h3>
          <div className="aspect-video relative">
            {loading && (
              <div className="absolute inset-0 flex items-center justify-center bg-black">
                <Loader2 className="w-8 h-8 text-[#39FF14] animate-spin" />
              </div>
            )}
            {error && (
              <div className="absolute inset-0 flex items-center justify-center bg-black">
                <p className="text-red-500">{error}</p>
              </div>
            )}
            <video
              ref={videoRef}
              className="w-full h-full"
              controls
              autoPlay
              playsInline
              preload="auto"
              controlsList="nodownload"
            >
              <source src={videoUrl} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
        </div>
      </div>
    </div>
  );
}