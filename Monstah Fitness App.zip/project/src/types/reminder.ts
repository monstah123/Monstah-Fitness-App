export interface Reminder {
  id: string;
  title: string;
  date: string;
  time: string;
  repeat: 'none' | 'daily' | 'weekly' | 'custom';
  days?: string[];
  userId: string;
}